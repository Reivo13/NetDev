from django.apps import AppConfig


class UploadresepappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'uploadresepapp'
